package com.example.tollapi.dto;

import lombok.Data;
import java.util.List;

@Data
public class TollResponse {
    private Route route;
    private List<TollDetails> tollPlazas;

    @Data
    public static class Route {
        private String sourcePincode;
        private String destinationPincode;
        private int distanceInKm;
    }

    @Data
    public static class TollDetails {
        private String name;
        private double latitude;
        private double longitude;
        private int distanceFromSource;
    }
}
