package com.example.tollapi.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class TollPlaza {
    private String tollName;
    private String state;
    private Double latitude;
    private Double longitude;

    public TollPlaza(String tollName, Double latitude, Double longitude) {
        this.tollName = tollName;
        this.latitude = latitude;
        this.longitude = longitude;
        this.state = null; 
    }
}
