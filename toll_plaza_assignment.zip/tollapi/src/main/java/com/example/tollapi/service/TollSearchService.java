package com.example.tollapi.service;

import com.example.tollapi.dto.TollRequest;
import com.example.tollapi.dto.TollResponse;
import com.example.tollapi.model.TollPlaza;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
@RequiredArgsConstructor
public class TollSearchService {

    private final TollDataLoader tollDataLoader;

    public TollResponse findNearbyTolls(TollRequest request) {
        String source = request.getSourcePincode();
        String destination = request.getDestinationPincode();

        if (!source.matches("\\d{6}") || !destination.matches("\\d{6}")) {
            throw new IllegalArgumentException("Invalid source or destination pincode");
        }
        if (source.equals(destination)) {
            throw new IllegalArgumentException("Source and destination pincodes cannot be the same");
        }

        List<double[]> mockRoute = getMockRoute();

        List<TollResponse.TollDetails> nearbyTolls = new ArrayList<>();
        for (TollPlaza plaza : tollDataLoader.getTollPlazas()) {
            for (double[] point : mockRoute) {
                double distance = distanceInKm(plaza.getLatitude(), plaza.getLongitude(), point[0], point[1]);
                if (distance <= 25) {
                    TollResponse.TollDetails toll = new TollResponse.TollDetails();
                    toll.setName(plaza.getTollName());
                    toll.setLatitude(plaza.getLatitude());
                    toll.setLongitude(plaza.getLongitude());
                    toll.setDistanceFromSource((int) distance);
                    nearbyTolls.add(toll);
                    break;
                }
            }
        }

        TollResponse.Route routeInfo = new TollResponse.Route();
        routeInfo.setSourcePincode(source);
        routeInfo.setDestinationPincode(destination);
        routeInfo.setDistanceInKm(850); 

        TollResponse response = new TollResponse();
        response.setRoute(routeInfo);
        response.setTollPlazas(nearbyTolls);

        return response;
    }

    private List<double[]> getMockRoute() {
        List<double[]> points = new ArrayList<>();
        points.add(new double[]{13.0598, 77.7705}); 
        points.add(new double[]{13.0, 77.5});      
        points.add(new double[]{12.95, 77.2});      
        points.add(new double[]{12.75, 76.6});      
        points.add(new double[]{15.36, 75.12});     
        points.add(new double[]{16.7, 74.22});      
        points.add(new double[]{18.52, 73.8567});   
        return points;
    }

    private double distanceInKm(double lat1, double lon1, double lat2, double lon2) {
        int R = 6371;
        double dLat = Math.toRadians(lat2 - lat1);
        double dLon = Math.toRadians(lon2 - lon1);
        double a = Math.sin(dLat / 2) * Math.sin(dLat / 2)
                 + Math.cos(Math.toRadians(lat1)) * Math.cos(Math.toRadians(lat2))
                 * Math.sin(dLon / 2) * Math.sin(dLon / 2);
        double c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
        return R * c;
    }
}
