package com.example.tollapi.controller;

import com.example.tollapi.dto.TollRequest;
import com.example.tollapi.dto.TollResponse;
import com.example.tollapi.service.TollSearchService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.bind.annotation.PostMapping;
import jakarta.validation.Valid;
@RestController
@RequestMapping("/api/v1")
@RequiredArgsConstructor
public class TollSearchController {

    private final TollSearchService tollSearchService;

   @PostMapping("/toll-plazas")
public ResponseEntity<TollResponse> findTollsBetweenPincodes(@RequestBody @Valid TollRequest request) {
    TollResponse response = tollSearchService.findNearbyTolls(request);
    return ResponseEntity.ok(response);
}

}
