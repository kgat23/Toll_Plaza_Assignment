package com.example.tollapi.dto;

import lombok.Data;
import jakarta.validation.constraints.NotBlank;

@Data
public class TollRequest {
    @NotBlank(message = "Source pincode is required")
    private String sourcePincode;

    @NotBlank(message = "Destination pincode is required")
    private String destinationPincode;
}