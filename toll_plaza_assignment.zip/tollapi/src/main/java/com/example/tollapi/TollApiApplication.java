package com.example.tollapi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TollApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(TollApiApplication.class, args);
	}

}
