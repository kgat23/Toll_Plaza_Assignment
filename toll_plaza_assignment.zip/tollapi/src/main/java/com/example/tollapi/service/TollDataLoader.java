package com.example.tollapi.service;

import com.example.tollapi.model.TollPlaza;
import jakarta.annotation.PostConstruct;
import org.springframework.stereotype.Service;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;

@Service
public class TollDataLoader {

    private List<TollPlaza> tollPlazas = new ArrayList<>();
    public List<TollPlaza> getTollPlazas() {
    return tollPlazas;
}

    @PostConstruct
    public void loadCSV() {
        InputStream is = getClass().getResourceAsStream("/toll_plaza_india.csv");
        if (is == null) {
            System.out.println(" CSV resource not found!");
            return;
        }
        try (BufferedReader reader = new BufferedReader(new InputStreamReader(is))) {

            String line;
            reader.readLine(); 

            while ((line = reader.readLine()) != null) {
                String[] tokens = line.split("\t");
                if (tokens.length < 4) continue;

                TollPlaza plaza = new TollPlaza();
                plaza.setLongitude(Double.parseDouble(tokens[0].trim()));
                plaza.setLatitude(Double.parseDouble(tokens[1].trim()));
                plaza.setTollName(tokens[2].trim());
                plaza.setState(tokens[3].trim());

                tollPlazas.add(plaza);
            }

            System.out.println(" Toll plazas loaded: " + tollPlazas.size());

        } catch (Exception e) {
            e.printStackTrace();
            System.out.println(" Failed to load toll plaza data.");
        }
    }
}